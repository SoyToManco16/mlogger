function mlogdelimit {
    local del=$1
    local num=$2
    printf '%*s\n' $num | tr ' ' "$del"
    # Uso: mlgdelimit '*_-#' 50
}

 # Obtener información del SO
    SO=$(hostnamectl | awk ' /Operating System/ {print $3, $4, $5}')
    KERNELV=$(hostnamectl | awk '/Kernel/ {print $3, $4}')
    SNAME=$(hostname)
    HWM=$(hostnamectl | awk ' /Hardware Model/ {print $3, $4, $5}')

    # Información de la CPU
    ARCH=$(lscpu | awk ' /Arquitectura:/ {print $2}')
    CPUM=$(lscpu | awk ' /Nombre del modelo:/ {print $4, $5, $6, $7, $8, $9}')
    CPUC=$(lscpu | grep "^CPU(s):" | awk '{print $2}')

    # Información de la memoria
    TMEM=$(lsmem | awk ' /Memoria total en línea:/ {print $5}')
    NUMEM=$(lsmem | awk ' /Memoria total fuera de línea:/ {print $6}')
    TMIE=$(dmidecode -t memory | awk ' /Maximum Capacity:/  {print $3 $4}')

    # Obtener Información de los dispositivos de almacenamiento y su tamaño
    DISKSINFO=$(lsblk -d -o NAME,SIZE | awk 'NR>1 {print "Disco: "$1" -->  Tamaño: "$2}')

    # INFORMACIÓN MOSTRADA POR EL SCRIPT
    echo 
    echo "INFORMACIÓN DEL SISTEMA"
    mlogdelimit '=' 70
    echo "Información general"
    echo "Nombre del sistema: $SNAME"
    echo "SO Instalado: $SO"
    echo "Version del kernel: $KERNELV"
    echo "Modelo de hardware: $HWM"
    mlogdelimit '=' 70
    echo "Información de la CPU"
    echo "Modelo de la CPU: $CPUM"
    echo "Núcleos de la CPU: $CPUC"
    echo "Arquitectura del procesador: $ARCH"
    mlogdelimit '=' 70
    echo "Información de la memoria RAM"
    echo "Memoria total instalada: $TMEM"
    echo "Memoria total no usada: $NUMEM"
    echo "Memoria total instalable: $TMIE"