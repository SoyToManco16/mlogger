#!/bin/bash

# Variables globales 
mlog="/var/log/mlog"
LOCKFILE="/tmp/my_script.lock"

# Diccionario de servicios con sus niveles de criticidad
declare -A servcatlog=(
    # Nivel 0: Críticos
    ["networking"]="0"
    ["sshd"]="0"
    ["cron"]="0"
    ["rsyslog"]="0"
    ["systemd-journald"]="0"
    ["firewalld"]="0"
    ["ufw"]="0"
    [ntp]="0"
    [chrony]="0"

    # Nivel 1: Importantes
    ["mysql"]="1"
    ["mariadb"]="1"
    ["postgresql"]="1"
    ["redis"]="1"
    ["apache2"]="1"
    ["nginx"]="1"
    ["php7.4-fpm"]="1"
    ["lvm2-monitor"]="1"
    ["blk-availability"]="1"
    ["apparmor"]="1"
    ["selinux"]="1"
    ["fail2ban"]="1"
    ["nfs-server"]="1"
    ["rpcbind"]="1"

    # Nivel 2: Menos críticos
    ["docker"]="2"
    ["containerd"]="2"
    ["lvm2-monitor"]="2"
    ["libvirtd"]="2"
    ["kubelet"]="2"
    ["snapd"]="2"
    ["cups"]="2"
    ["openvnp"]="2"
    ["tomcat"]="2"
    ["wildfly"]="2"
)


# Asegurarse de que el archivo de log existe
function logfile {
    if [[ ! -e "$mlog" ]]; then
        touch "$mlog" || { echo "Error al crear el archivo de log"; exit 1; }
    fi
}

# Elimina el LOCKFILE si existe al iniciar el script (por si el servicio fue detenido previamente)
if [[ -e "$LOCKFILE" ]]; then
    rm -f "$LOCKFILE"
fi

# Crea el LOCKFILE y define la trampa para eliminarlo al salir
touch "$LOCKFILE"
trap 'rm -f $LOCKFILE; exit' EXIT SIGINT SIGTERM

# Función para agregar la hora al log
mlogtime() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$mlog"
}

# Función para 'Flaggear' los eventos que van al logger
function mloggerflags {
    local nivel=$1
    local flag=$2

    case "$nivel" in 
        0) logger -p user.emerg "$flag";; # Pánico en el sistema
        1) logger -p user.alert "$flag";; # Alerta
        2) logger -p user.crit "$flag";; # Crítico
        3) logger -p user.err "$flag";; # Error
        4) logger -p user.warning "$flag";; # Advertencia
        5) logger -p user.notice "$flag";; # Aviso
        6) logger -p user.info "$flag";; # Información
        7) logger -p user.debug "$flag";; # Depuración
    esac
}

# Función para verificar la conexión a internet cada 15 minutos
function connection {
    ping -c 4 8.8.8.8 >> /dev/null
    if [[ $? -ne 0 ]]; then  
        mloggerflags 2 "CRITICAL: El servidor no tiene conexión a internet, por favor revise el servidor"
    else
        mlogtime "El servidor tiene conexión a internet"
    fi
}

# Función para monitorear el uso de la CPU cada 10 segundos
function CPUsage {
    uso_cpu=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')
    if [[ $(echo "$uso_cpu > 90" | bc) -eq 1 ]]; then
        mloggerflags 2 "CRITICAL: El uso de la CPU ha sobrepasado el 90%, por favor revise el servidor"
    elif [[ $(echo "$uso_cpu > 80" | bc) -eq 1 ]]; then
        mlogtime "WARNING: El uso de la CPU ha sobrepasado el 80%"
    fi
}

# Función para monitorear el uso de la RAM cada 10 segundos
function RAMUsage {
    uso_ram=$(top -bn1 | grep "MiB Mem" | awk '{print ($8/$4) * 100}')
    if [[ $(echo "$uso_ram > 90" | bc) -eq 1 ]]; then
        mloggerflags 2 "CRITICAL: El uso de la memoria ha superado el 90%!!"
    elif [[ $(echo "$uso_ram > 80" | bc) -eq 1 ]]; then 
        mlogtime "WARNING: El uso de la memoria ha superado el 80%"
    fi
}

# Función para monitorear el espacio del disco cada 5 minutos
function DiskUsage {
    df -h | grep -E '^/dev/' | awk '{print $1 " " $5}' | while read line; do
        partition=$(echo $line | awk '{print $1}')
        usage=$(echo $line | awk '{print $2}' | sed 's/%//')
        if [[ $usage -gt 95 ]]; then
            mloggerflags 0 "PANIC: El uso del disco en $partition ha sobrepasado el 95%, por favor revise el servidor"
        elif [[ $usage -gt 90 ]]; then
            mloggerflags 1 "ALERT: El uso del disco en $partition ha sobrepasado el 90%, por favor revise el servidor"
        elif [[ $usage -gt 80 ]]; then
            mlogtime "WARNING: El uso del disco en $partition ha sobrepasado el 80%"
        fi
    done
}

# Función para verificar y categorizar servicios críticos
function checkCritSrvcs {
    for service in "${!servcatlog[@]}"; do
        local level="${servcatlog[$service]}"
        
        # Verificar si el servicio está instalado
        if ! systemctl list-units --type=service --all | grep -q "$service.service"; then
            continue
        fi
        
        # Verificar si el servicio está activo
        if ! systemctl is-active --quiet "$service"; then
            case "$level" in
                0)
                    mloggerflags 0 "CRITICAL: El servicio $service está detenido o fallando"
                    ;;
                1)
                    mloggerflags 1 "ALERT: El servicio $service no está activo"
                    ;;
                2)
                    mlogtime "WARNING: El servicio $service no está activo"
                    ;;
            esac
        else
            mlogtime "El servicio $service está activo."
        fi
    done
}


# Función para monitorear el tiempo activo del sistema
function servuptimeuser {
    uptimeInfo=$(uptime | awk -F 'up |,|:| ' '{
        if ($2 ~ /days?/) {
            print "Tiempo del servidor activo:", $2 " días, " $4 " horas y " $5 " minutos"
        } else if ($2 ~ /min/) {
            print "Tiempo del servidor activo:", $2 " minutos"
        } else {
            print "Tiempo del servidor activo:", $2 " horas y " $3 " minutos"
        }
    }')
    mlogtime "$uptimeInfo"
    mloggerflags 6 "$uptimeInfo"
}

# Función para mostrar los usuarios conectados a el servidor
function userss {
    usercnt=$(uptime | awk '{print $5}')  # Cuenta el número de usuarios conectados

    # Si hay más de un usuario, mostramos "usuarios conectados", de lo contrario "usuario conectado"
    if [[ $usercnt -eq 1 ]]; then
        users="$usercnt usuario conectado"
    else
        users="$usercnt usuarios conectados"
    fi

    mlogtime "$users"
    mloggerflags 6 "$users"
}

# Monitoreo en bucles separados
(
    while true; do 
        servuptimeuser
        sleep 3600
    done
) &

(
    while true; do 
        connection
        userss
        sleep 900
    done
) &

(
    while true; do 
        DiskUsage
        checkCritSrvcs
        sleep 300
    done
) &

(
    while true; do 
        CPUsage
        RAMUsage
        sleep 10
    done
) &

# Esperar a que los procesos secundarios terminen
wait

# Eliminar el archivo de bloqueo al salir
rm -f $LOCKFILE
