#!/bin/bash

# Variables globales 
mlog="/var/log/mlog"
LOCKFILE="/tmp/my_script.lock"

# Diccionario de servicios con sus niveles de criticidad
declare -A servcatlog=(
    # Nivel 0: Críticos
    ["networking"]="0"
    ["sshd"]="0"
    ["cron"]="0"
    ["rsyslog"]="0"
    ["systemd-journald"]="0"
    ["firewalld"]="0"
    ["ufw"]="0"
    ["ntp"]="0"
    ["chrony"]="0"

    # Nivel 1: Importantes
    ["mysql"]="1"
    ["mariadb"]="1"
    ["postgresql"]="1"
    ["redis"]="1"
    ["apache2"]="1"
    ["nginx"]="1"
    ["php7.4-fpm"]="1"
    ["lvm2-monitor"]="1"
    ["blk-availability"]="1"
    ["apparmor"]="1"
    ["selinux"]="1"
    ["fail2ban"]="1"
    ["nfs-server"]="1"
    ["rpcbind"]="1"

    # Nivel 2: Menos críticos
    ["docker"]="2"
    ["containerd"]="2"
    ["lvm2-monitor"]="2"
    ["libvirtd"]="2"
    ["kubelet"]="2"
    ["snapd"]="2"
    ["cups"]="2"
    ["openvnp"]="2"
    ["tomcat"]="2"
    ["wildfly"]="2"
)


# Asegurarse de que el archivo de log existe
function logfile {
    if [[ ! -e "$mlog" ]]; then
        touch "$mlog" || { echo "Error al crear el archivo de log"; exit 1; }
    fi
}

# Elimina el LOCKFILE si existe al iniciar el script (por si el servicio fue detenido previamente)
if [[ -e "$LOCKFILE" ]]; then
    rm -f "$LOCKFILE"
fi

# Crea el LOCKFILE y define la trampa para eliminarlo al salir
touch "$LOCKFILE"
trap 'rm -f $LOCKFILE; exit' EXIT SIGINT SIGTERM

# Función para agregar la hora al log
mlogtime() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$mlog"
}

# Función para 'Flaggear' los eventos que van al logger
function mloggerflags {
    local nivel=$1
    local flag=$2

    case "$nivel" in 
        0) logger -p user.emerg "$flag";; # Pánico en el sistema
        1) logger -p user.alert "$flag";; # Alerta
        2) logger -p user.crit "$flag";; # Crítico
        3) logger -p user.err "$flag";; # Error
        4) logger -p user.warning "$flag";; # Advertencia
        5) logger -p user.notice "$flag";; # Aviso
        6) logger -p user.info "$flag";; # Información
        7) logger -p user.debug "$flag";; # Depuración
    esac
}

# Función para verificar la conexión a internet cada 15 minutos
function connection {
    ping -c 4 8.8.8.8 >> /dev/null
    if [[ $? -ne 0 ]]; then  
        mloggerflags 2 "CRITICAL: El servidor no tiene conexión a internet, por favor revise el servidor"
    else
        mlogtime "El servidor tiene conexión a internet"
    fi
}

# Función para monitorear el uso de la CPU cada 10 segundos
function CPUsage {
    uso_cpu=$(top -bn1 | grep "Cpu(s)" | awk '{print $2 + $4}')
    if [[ $(echo "$uso_cpu > 90" | bc) -eq 1 ]]; then
        mloggerflags 2 "CRITICAL: El uso de la CPU ha sobrepasado el 90%, por favor revise el servidor"
    elif [[ $(echo "$uso_cpu > 80" | bc) -eq 1 ]]; then
        mlogtime "WARNING: El uso de la CPU ha sobrepasado el 80%"
    fi
}

# Función para monitorear el uso de la RAM cada 10 segundos
function RAMUsage {
    uso_ram=$(top -bn1 | grep "MiB Mem" | awk '{print ($8/$4) * 100}')
    if [[ $(echo "$uso_ram > 90" | bc) -eq 1 ]]; then
        mloggerflags 2 "CRITICAL: El uso de la memoria ha superado el 90%!!"
    elif [[ $(echo "$uso_ram > 80" | bc) -eq 1 ]]; then 
        mlogtime "WARNING: El uso de la memoria ha superado el 80%"
    fi
}

# Función para monitorear el espacio del disco cada 5 minutos
function DiskUsage {
    df -h | grep -E '^/dev/' | awk '{print $1 " " $5}' | while read line; do
        partition=$(echo $line | awk '{print $1}')
        usage=$(echo $line | awk '{print $2}' | sed 's/%//')
        if [[ $usage -gt 95 ]]; then
            mloggerflags 0 "PANIC: El uso del disco en $partition ha sobrepasado el 95%, por favor revise el servidor"
        elif [[ $usage -gt 90 ]]; then
            mloggerflags 1 "ALERT: El uso del disco en $partition ha sobrepasado el 90%, por favor revise el servidor"
        elif [[ $usage -gt 80 ]]; then
            mlogtime "WARNING: El uso del disco en $partition ha sobrepasado el 80%"
        fi
    done
}

# Función para verificar y categorizar servicios críticos
function checkCritSrvcs {
    for service in "${!servcatlog[@]}"; do
        local level="${servcatlog[$service]}"
        
        # Verificar si el servicio está instalado
        if ! systemctl list-units --type=service --all | grep -q "$service.service"; then
            continue
        fi
        
        # Verificar si el servicio está activo
        if ! systemctl is-active --quiet "$service"; then
            case "$level" in
                0)
                    mloggerflags 0 "CRITICAL: El servicio $service está detenido o fallando"
                    ;;
                1)
                    mloggerflags 1 "ALERT: El servicio $service no está activo"
                    ;;
                2)
                    mlogtime "WARNING: El servicio $service no está activo"
                    ;;
            esac
        else
            mlogtime "El servicio $service está activo."
        fi
    done
}

# Funciones para monitorizar los logs del sistema en caso de errores:
# Función para monitorear errores en syslog
function check_syslog_errors {
    echo "Buscando errores en syslog..."
    if [[ -f /var/log/syslog ]]; then
        grep -i "error" /var/log/syslog | tail -n 20
    fi
}

# Función para monitorear fallos de autenticación en auth.log
function check_authlog_errors {
    echo "Buscando fallos de autenticación en auth.log..."
    if [[ -f /var/log/auth.log ]]; then
        grep -i "failed password" /var/log/auth.log | tail -n 20
    fi
}

# Función para monitorear errores en kern.log
function check_kernlog_errors {
    echo "Buscando errores en kern.log..."
    if [[ -f /var/log/kern.log ]]; then
        grep -i "error" /var/log/kern.log | tail -n 20
    fi
}

# Función para monitorear errores en las actualizaciones de APT
function check_apt_errors {
    echo "Buscando errores de APT en history.log..."
    if [[ -f /var/log/apt/history.log ]]; then
        grep -i "error" /var/log/apt/history.log | tail -n 20
    fi
}

# Función para monitorear errores en daemon.log
function check_daemonlog_errors {
    echo "Buscando errores en daemon.log..."
    if [[ -f /var/log/daemon.log ]]; then
        grep -i "error" /var/log/daemon.log | tail -n 20
    fi
}

# Función para monitorear errores en mysql/error.log
function check_mysql_errors {
    echo "Buscando errores en MySQL error.log..."
    if [[ -f /var/log/mysql/error.log ]]; then
        grep -i "error" /var/log/mysql/error.log | tail -n 20
    fi
}

# Función para monitorear intentos de acceso bloqueados en ufw.log
function check_ufw_errors {
    echo "Buscando intentos de acceso bloqueados en ufw.log..."
    if [[ -f /var/log/ufw.log ]]; then
        grep -i "BLOCK" /var/log/ufw.log | tail -n 20
    fi
}

# Función para monitorear errores en mail.log
function check_maillog_errors {
    echo "Buscando errores en mail.log..."
    if [[ -f /var/log/mail.log ]]; then
        grep -i "error" /var/log/mail.log | tail -n 20
    fi
}

# Función para monitorear errores en apache2/error.log
function check_apache_errors {
    echo "Buscando errores en apache2/error.log..."
    if [[ -f /var/log/apache2/error.log ]]; then
        grep -i "error" /var/log/apache2/error.log | tail -n 20
    fi
}

# Función para monitorear errores en cron.log
function check_cron_errors {
    echo "Buscando errores en cron.log..."
    if [[ -f /var/log/cron.log ]]; then
        grep -i "error" /var/log/cron.log | tail -n 20
    fi
}

# Función para monitorear errores en boot.log
function check_bootlog_errors {
    echo "Buscando errores en boot.log..."
    if [[ -f /var/log/boot.log ]]; then
        grep -i "error" /var/log/boot.log | tail -n 20
    fi
}


# Función para monitorear el tiempo activo del sistema
function servuptimeuser {
    uptimeInfo=$(uptime | awk -F 'up |,|:| ' '{
        if ($2 ~ /days?/) {
            print "Tiempo del servidor activo:", $2 " días, " $4 " horas y " $5 " minutos"
        } else if ($2 ~ /min/) {
            print "Tiempo del servidor activo:", $2 " minutos"
        } else {
            print "Tiempo del servidor activo:", $2 " horas y " $3 " minutos"
        }
    }')
    mlogtime "$uptimeInfo"
    mloggerflags 6 "$uptimeInfo"
}

# Función para mostrar los usuarios conectados a el servidor
function conectedusers {
    # Cuenta los usuarios únicos conectados
    usercnt=$(who | awk '{print $1}' | sort | uniq | wc -l)

    # Si hay más de un usuario, mostramos "usuarios conectados", de lo contrario "usuario conectado"
    if [[ $usercnt -eq 1 ]]; then
        users="$usercnt usuario conectado a el servidor"
    else
        users="$usercnt usuarios conectados a el servidor"
    fi

    mlogtime "$users"
    mloggerflags 6 "$users"
}

# Monitoreo en bucles separados
(
    while true; do 
        servuptimeuser
        check_mysql_errors
        check_apache_errors
        check_maillog_errors
        check_cron_errors
        check_kernlog_errors
        sleep 3600
    done
) &

(
    while true; do 
        connection
        conectedusers
        check_syslog_errors
        check_daemonlog_errors
        check_authlog_errors
        sleep 900
    done
) &

(
    while true; do 
        DiskUsage
        checkCritSrvcs
        sleep 300
    done
) &

(
    while true; do 
        CPUsage
        RAMUsage
        sleep 10
    done
) &

# Esperar a que los procesos secundarios terminen
wait

# Eliminar el archivo de bloqueo al salir
rm -f $LOCKFILE
